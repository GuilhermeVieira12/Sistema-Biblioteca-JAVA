package br.edu.biblioteca.exception;

public class MaterialNaoEncontradoException extends Exception {
	public MaterialNaoEncontradoException(String mensagem) {
		super(mensagem);
		}
	}



	
