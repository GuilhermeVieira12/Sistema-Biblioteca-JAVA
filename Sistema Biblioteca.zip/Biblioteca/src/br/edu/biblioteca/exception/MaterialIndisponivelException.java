package br.edu.biblioteca.exception;

public class MaterialIndisponivelException extends Exception {
    public MaterialIndisponivelException(String mensagem) {
        super(mensagem);
    }
}
