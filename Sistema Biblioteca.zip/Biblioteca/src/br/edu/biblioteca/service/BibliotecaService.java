package br.edu.biblioteca.service;
import java.util.ArrayList;
import java.util.List;
import br.edu.biblioteca.model.Material;
import br.edu.biblioteca.model.Usuario;
import br.edu.biblioteca.exception.MaterialNaoEncontradoException;
import br.edu.biblioteca.exception.UsuarioNaoEncontradoException;

public class BibliotecaService {
    
    private List<Material> acervo;
    private List<Usuario> usuarios;

    public BibliotecaService() {
        this.acervo = new ArrayList<>();
        this.usuarios = new ArrayList<>();
    }

    public void cadastrarMaterial(Material material) {
        
        for (Material m : acervo) {
            if (m.getId() == material.getId()) {
                System.out.println("ERRO: Já existe um material cadastrado com o ID " + material.getId());
                return; 
            }
        }
        acervo.add(material);
        System.out.println("Material cadastrado com sucesso!");
    }

    public void cadastrarUsuario(Usuario usuario) {
       
        for (Usuario u : usuarios) {
            if (u.getId() == usuario.getId()) {
                System.out.println("ERRO: Já existe um usuário cadastrado com o ID " + usuario.getId());
                return;
            }
        }
        usuarios.add(usuario);
        System.out.println("Usuário registrado com sucesso no sistema!");
    }

    public void listarMateriais() {
        if (acervo.isEmpty()) {
            System.out.println("O acervo está vazio.");
            return;
        }
        System.out.println("\n--- ITENS NO ACERVO ---");
        for (Material m : acervo) {
            System.out.println(m.exibirDetalhes()); 
        }
    }

   
    public Material buscarMaterialPorId(int id) throws MaterialNaoEncontradoException {
        for (Material m : acervo) {
            if (m.getId() == id) return m;
        }
        throw new MaterialNaoEncontradoException("ERRO: Material com ID " + id + " não existe no acervo.");
    }

   
    public Usuario buscarUsuarioPorId(int id) throws UsuarioNaoEncontradoException {
        for (Usuario u : usuarios) {
            if (u.getId() == id) return u;
        }
        throw new UsuarioNaoEncontradoException("ERRO: Usuário com ID " + id + " não encontrado.");
    }
}


	