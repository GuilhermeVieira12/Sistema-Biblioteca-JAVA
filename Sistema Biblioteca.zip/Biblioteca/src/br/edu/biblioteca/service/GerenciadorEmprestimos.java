package br.edu.biblioteca.service;
import java.util.ArrayList;
import java.util.List;
import br.edu.biblioteca.model.Emprestimo;
import br.edu.biblioteca.model.Material;
import br.edu.biblioteca.model.Usuario;
import br.edu.biblioteca.contract.Emprestavel;
import br.edu.biblioteca.contract.Renovavel;
import br.edu.biblioteca.exception.MaterialNaoEncontradoException;
import br.edu.biblioteca.exception.UsuarioNaoEncontradoException;
import br.edu.biblioteca.exception.MaterialIndisponivelException;

public class GerenciadorEmprestimos {

    private List<Emprestimo> emprestimos;
    private BibliotecaService biblioteca; 

    public GerenciadorEmprestimos(BibliotecaService biblioteca) {
        this.emprestimos = new ArrayList<>();
        this.biblioteca = biblioteca;
    }

  
    public void realizarEmprestimo(int idMaterial, int idUsuario) throws MaterialNaoEncontradoException, UsuarioNaoEncontradoException, MaterialIndisponivelException {
        Material material = biblioteca.buscarMaterialPorId(idMaterial);
        Usuario usuario = biblioteca.buscarUsuarioPorId(idUsuario);

        if (!material.getStatus().equals("DISPONÍVEL")) {
            throw new MaterialIndisponivelException("ERRO: O material já está emprestado!");
        }

        if (material instanceof Emprestavel) {
            ((Emprestavel) material).emprestar(); 
        }

        Emprestimo novoEmprestimo = new Emprestimo(material, usuario);
        emprestimos.add(novoEmprestimo);
        System.out.println("-> Empréstimo registrado com sucesso! Devolução: " + novoEmprestimo.getDataDevolucaoPrevista());
    }

    public void devolverMaterial(int idMaterial) throws MaterialNaoEncontradoException {
        Material material = biblioteca.buscarMaterialPorId(idMaterial);
        
        if (material instanceof Emprestavel) {
            ((Emprestavel) material).devolver();
        }

        for (Emprestimo e : emprestimos) {
            if (e.getMaterial().getId() == idMaterial && e.isAtivo()) {
                e.setAtivo(false);
                System.out.println("-> Devolução registrada no sistema.");
                break;
            }
        }
    }

    public void renovarMaterial(int idMaterial) throws MaterialNaoEncontradoException {
        Material material = biblioteca.buscarMaterialPorId(idMaterial);
        
        if (material instanceof Renovavel) {
            ((Renovavel) material).renovar(); 
            
            for (Emprestimo e : emprestimos) {
                if (e.getMaterial().getId() == idMaterial && e.isAtivo()) {
                    e.setDataDevolucaoPrevista(e.getDataDevolucaoPrevista().plusDays(7));
                    System.out.println("-> Nova data de devolução: " + e.getDataDevolucaoPrevista());
                    break;
                }
            }
        } else {
           
            throw new IllegalArgumentException("ERRO: Este tipo de material (Revista) não pode ser renovado!");
        }
    }
}