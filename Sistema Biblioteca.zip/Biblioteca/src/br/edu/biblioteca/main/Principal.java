package br.edu.biblioteca.main;
import java.util.Scanner;
import br.edu.biblioteca.model.Livro;
import br.edu.biblioteca.model.Revista;
import br.edu.biblioteca.model.Usuario;
import br.edu.biblioteca.service.BibliotecaService;
import br.edu.biblioteca.service.GerenciadorEmprestimos;
import br.edu.biblioteca.exception.MaterialNaoEncontradoException;
import br.edu.biblioteca.exception.UsuarioNaoEncontradoException;
import br.edu.biblioteca.exception.MaterialIndisponivelException;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
       
        BibliotecaService bibliotecaService = new BibliotecaService();
        GerenciadorEmprestimos gerenciadorEmprestimos = new GerenciadorEmprestimos(bibliotecaService);
        
        int opcao;
        
        do {
            System.out.println("\n=== BEM-VINDO AO SISTEMA DE BIBLIOTECA ===");
            System.out.println("1. Cadastrar Material (Livro/Revista)");
            System.out.println("2. Cadastrar Usuário");
            System.out.println("3. Realizar Empréstimo");
            System.out.println("4. Listar Materiais");
            System.out.println("5. Devolver/Renovar");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
        
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                        
                case 1:
                    System.out.println("\n=== Cadastrar Material ===");
                    System.out.print("Tipo de Material (1- Livro/2- Revista): ");
                    int tipoMaterial = scanner.nextInt();
                    scanner.nextLine();
                    
                    System.out.print("Digite o ID único: ");
                    int idMaterial = scanner.nextInt();
                    scanner.nextLine();
                    
                    System.out.print("Digite o título: ");
                    String titulo = scanner.nextLine();

                    System.out.print("Digite o ano de publicação: ");
                    int ano = scanner.nextInt();
                    scanner.nextLine();
                    
                    if (tipoMaterial == 1) {
                        System.out.print("Digite o autor do Livro: ");
                        String autor = scanner.nextLine();
                        System.out.print("Digite o ISBN: ");
                        String isbn = scanner.nextLine();
                        System.out.print("Digite o número de páginas: ");
                        int paginas = scanner.nextInt();
                        scanner.nextLine();
                        
                        
                        Livro novoLivro = new Livro(idMaterial, titulo, ano, autor, isbn, paginas);
                        bibliotecaService.cadastrarMaterial(novoLivro);
                        
                    } else if (tipoMaterial == 2) {
                    	
                        System.out.print("Digite a edição da Revista: ");
                        int edicao = scanner.nextInt();
                        scanner.nextLine();
                        
                        System.out.print("Digite o mês de publicação: ");
                        String mes = scanner.nextLine();
                       
                        
                        Revista novaRevista = new Revista(idMaterial, titulo, ano, edicao, mes);
                        bibliotecaService.cadastrarMaterial(novaRevista);
                        
                    } else {
                        System.out.println("Tipo inválido!");
                    }
                    break;
                    
                case 2:
                    System.out.println("\n=== CADASTRAR USUÁRIO ===");
                    
                    System.out.print("Digite o ID do usuário: ");
                    int idUsuario = scanner.nextInt();
                    scanner.nextLine();
                    
                    System.out.print("Digite o nome do usuário: ");
                    String nome = scanner.nextLine();
                    
                   
                    Usuario novoUser = new Usuario(idUsuario, nome);
                    bibliotecaService.cadastrarUsuario(novoUser);
                    break;
                    
                case 3:
                    System.out.println("\n=== REALIZAR EMPRÉSTIMO ===");
                    
                    System.out.print("Digite o ID do material: ");
                    int idMatEmprestimo = scanner.nextInt();
                    scanner.nextLine();
                    
                    System.out.print("Digite o ID do usuário: ");
                    int idUserEmprestimo = scanner.nextInt();
                    scanner.nextLine();
                    
                    
                    try {
                        gerenciadorEmprestimos.realizarEmprestimo(idMatEmprestimo, idUserEmprestimo);
                    } catch (MaterialNaoEncontradoException | UsuarioNaoEncontradoException | MaterialIndisponivelException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                    
                case 4:
                    System.out.println("\n=== LISTAR MATERIAIS ===");
                    
                    bibliotecaService.listarMateriais();
                    break;
                    
                case 5:
                    System.out.println("\n=== DEVOLVER / RENOVAR ===");
                    
                    System.out.print("Digite o ID do material: ");
                    int idMatAcao = scanner.nextInt();
                    scanner.nextLine();
                    
                    System.out.print("Escolha a ação (1 - Devolver / 2 - Renovar): ");
                    int acao = scanner.nextInt();
                    scanner.nextLine();
                    
                    try {
                        if (acao == 1) {
                            gerenciadorEmprestimos.devolverMaterial(idMatAcao);
                        } else if (acao == 2) {
                            gerenciadorEmprestimos.renovarMaterial(idMatAcao);
                        } else {
                            System.out.println("Ação inválida!");
                        }
                    } catch (MaterialNaoEncontradoException | IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                    
                case 0:
                    System.out.println("\nSistema encerrado. Até logo!");
                    break;
                    
                default:
                    System.out.println("\nOpção inválida! Tente novamente.");
                    break;
            }
            
        } while (opcao != 0);

        scanner.close();
    }   
}
		
		
		
		
