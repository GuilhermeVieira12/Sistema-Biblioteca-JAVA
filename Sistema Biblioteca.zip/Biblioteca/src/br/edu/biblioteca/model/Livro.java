package br.edu.biblioteca.model;
import br.edu.biblioteca.contract.Emprestavel;
import br.edu.biblioteca.contract.Renovavel;

public class Livro extends Material implements Emprestavel, Renovavel {	
	private String autor;
    private String isbn;
    private int numeroPaginas;
    
    public Livro(int id, String titulo, int anoPublicacao, String autor, String isbn, int numeroPaginas) {
     
        super(id, titulo, anoPublicacao); 
        this.autor = autor;
        this.isbn = isbn;
        this.numeroPaginas = numeroPaginas;
    }
	
    @Override
    public String exibirDetalhes() {
        return "LIVRO [ID: " + getId() + " | Título: " + getTitulo() + " | Autor: " + autor + " | Status: " + getStatus() + "]";
    }
    

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }
    
    @Override
    public void emprestar() {
        this.status = "INDISPONÍVEL";
        System.out.println("Livro emprestado com sucesso!");
    }

    @Override
    public void devolver() {
        this.status = "DISPONÍVEL";
        System.out.println("Livro devolvido com sucesso!");
    }

    @Override
    public void renovar() {
        System.out.println("Prazo do livro renovado por mais 7 dias!");
    }
}