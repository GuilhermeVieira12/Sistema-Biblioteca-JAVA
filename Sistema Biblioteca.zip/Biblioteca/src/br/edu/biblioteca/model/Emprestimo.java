package br.edu.biblioteca.model;
import java.time.LocalDate;

public class Emprestimo {
	
    private Material material;
    private Usuario usuario;
    
    
    private LocalDate dataEmprestimo;
    private LocalDate dataDevolucaoPrevista;
    private boolean ativo; 

    
    public Emprestimo(Material material, Usuario usuario) {
        this.material = material;
        this.usuario = usuario;
        
        
        this.dataEmprestimo = LocalDate.now(); 
        
       
        this.dataDevolucaoPrevista = LocalDate.now().plusDays(7); 
        
       
        this.ativo = true; 
    }

   
    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(LocalDate dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public LocalDate getDataDevolucaoPrevista() {
        return dataDevolucaoPrevista;
    }

    public void setDataDevolucaoPrevista(LocalDate dataDevolucaoPrevista) {
        this.dataDevolucaoPrevista = dataDevolucaoPrevista;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
}
	
