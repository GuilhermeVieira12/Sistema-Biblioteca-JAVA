package br.edu.biblioteca.model;
import br.edu.biblioteca.contract.Emprestavel;

public class Revista extends Material implements Emprestavel {
	
	private int edicao;
    private String mesPublicacao;

    public Revista(int id, String titulo, int anoPublicacao, int edicao, String mesPublicacao) {
        super(id, titulo, anoPublicacao);
        this.edicao = edicao;
        this.mesPublicacao = mesPublicacao;
    }
    
    @Override
    public String exibirDetalhes() {
        return "REVISTA [ID: " + getId() + " | Título: " + getTitulo() + " | Edição: " + edicao + " | Mês: " + mesPublicacao + " | Status: " + getStatus() + "]";
    }

  
    public int getEdicao() {
        return edicao;
    }

    public void setEdicao(int edicao) {
        this.edicao = edicao;
    }

    public String getMesPublicacao() {
        return mesPublicacao;
    }

    public void setMesPublicacao(String mesPublicacao) {
        this.mesPublicacao = mesPublicacao;
    }
    
    @Override
    public void emprestar() {
        this.status = "INDISPONÍVEL";
        System.out.println("Revista emprestada com sucesso!");
    }

    @Override
    public void devolver() {
        this.status = "DISPONÍVEL";
        System.out.println("Revista devolvida com sucesso!");
    }
}
