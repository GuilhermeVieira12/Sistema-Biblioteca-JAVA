package br.edu.biblioteca.contract;

public interface Renovavel {
    void renovar();
}
