package br.edu.biblioteca.contract;

public interface Emprestavel {
	void emprestar();
	void devolver();
}


